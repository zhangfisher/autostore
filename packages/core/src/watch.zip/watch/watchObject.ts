import type { WatchOptions, WatchDescriptor } from "./types";
import type { Dict } from "../types";
import { isEq } from "../utils/isEq";
import type { AutoStore } from "../store/store";
import type { ComputedContext } from "../computed/types";
import { ObserverObject } from "../observer/observer";
import { markRaw } from "../utils";
import { emitStoreEvent } from "../utils/emitStoreEvent";

export class WatchObject<Value = any> extends ObserverObject<Value, WatchOptions<Value>> {
    private _cache?: Dict;
    constructor(
        public store: AutoStore<any>,
        descriptor: WatchDescriptor,
        context?: ComputedContext<any>,
    ) {
        super(store, descriptor, context);
        if (typeof this.options.filter !== "function")
            throw new Error("watch options.filter must be a function");
    }
    get filter() {
        return this.options.filter!;
    }
    get cache() {
        if (!this._cache) this._cache = {};
        return this._cache!;
    }
    toString() {
        return `WatchObject<${this.id}>`;
    }

    protected onInitial() {}
    /**
     * 侦听到值变化时调用本函数来判断是否匹配
     *
     * 如果是则执行监听函数
     *
     * @param dependPath
     * @param dependValue
     * @returns
     */
    isMatched(dependPath: string[], dependValue: any) {
        if (isEq(dependPath, this.path)) return false;
        return this.filter(dependPath, dependValue);
    }

    reset() {
        this._cache = {};
        this.value = this.initial as Value;
    }
    /**
     * 运行侦听函数
     * @param watchPath
     * @returns
     */
    run(watchPath: string[], watchValue: any) {
        // 1. 检查是否启用
        if (!this.enable) {
            return;
        }
        try {
            const getterArgs = {
                path: watchPath,
                value: watchValue,
            };
            emitStoreEvent(this.store, `observer/${this.id}/run`, {
                args: getterArgs,
                observer: this,
                scope: undefined,
            });
            // 2.  执行监听函数
            const result = this.getter?.call(this, getterArgs, this);
            if (this.options.raw) {
                markRaw(result);
            }
            this.value = result as Value;
            emitStoreEvent(this.store, `observer/${this.id}/done`, {
                value: result,
                observer: this,
            });
        } catch (e: any) {
            emitStoreEvent(this.store, `observer/${this.id}/error`, { error: e, observer: this });
        }
    }
}
